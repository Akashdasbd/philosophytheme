 <?php 
/** 
 
 * Plugin Name:       Philosopy componiy 
 * Plugin URI:        https://www.philosopy.com
 * Description:       philosopy WordPress with powerful, professional and intuitive fields.
 * Version:           1.0.0
 * Author:            akahs
 * Author URI:        https://akash.com
 * Text Domain:       philosopy_componiy
 * License:     GPLv2 or later
 * Requires PHP:      7.0
 * Requires at least: 5.8
 */


 function philosopy_componiy_cptui_register_my_cpts_book() {

	/**
	 * Post Type: Books.
	 */

	$labels = [
		"name" => esc_html__( "Books", "pilosopy" ),
		"singular_name" => esc_html__( "Book", "pilosopy" ),
		"menu_name" => esc_html__( "Books", "pilosopy" ),
		"all_items" => esc_html__( "All Books", "pilosopy" ),
		"add_new" => esc_html__( "add Book", "pilosopy" ),
		"add_new_item" => esc_html__( "Add new book", "pilosopy" ),
		"edit_item" => esc_html__( "edit book", "pilosopy" ),
		"new_item" => esc_html__( "new book", "pilosopy" ),
		"view_item" => esc_html__( "view book", "pilosopy" ),
		"view_items" => esc_html__( "view books", "pilosopy" ),
	];

	$args = [
		"label" => esc_html__( "Books", "pilosopy" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"rest_namespace" => "wp/v2",
		"has_archive" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"can_export" => false,
		"rewrite" => [ "slug" => "book", "with_front" => true ],
		"query_var" => true,
		"menu_icon" => "dashicons-book",
		"supports" => [ "title", "editor", "thumbnail" ],
		"show_in_graphql" => false,
	];

	register_post_type( "book", $args );
}

add_action( 'init', 'philosopy_componiy_cptui_register_my_cpts_book' );





 ?>